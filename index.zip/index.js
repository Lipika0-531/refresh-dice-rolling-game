alert("hello");
List= ["images/dice1.png" ,"images/dice2.png", "images/dice3.png" ,"images/dice4.png" ,"images/dice5.png","images/dice6.png"  ]
let pl1Random = Math.round(Math.random()*6)
let pl2Random = Math.round(Math.random()*6)
document.getElementById("pl1-dice").setAttribute('src',List[pl1Random]);
document.getElementById("pl2-dice").setAttribute('src',List[pl2Random]);

 if(pl1Random > pl2Random){
    document.querySelector("#winner").innerHTML= "player 1 wins";

 }

 else if (pl1Random === pl2Random){
   document.querySelector("#winner").innerHTML= "draw the match";
 }

 else{
   document.querySelector("#winner").innerHTML= "player 2 wins";

}
},3000);
